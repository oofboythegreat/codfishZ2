 #Project 4, CSSE
#Ben du Preez, Miechal Nilsen, Ryan Barger
#11/4/24
# ' CODfish zombies ' 

#imported stuff
from pgzfixer import *
import pgzrun
from random import randint
import math
import time
import pygame
m = (0, 0)
#all our variables
speedupgrade = 0
lifeupgrade = 0
level = 0
zspeed = 1
WIDTH = 800
HEIGHT = 600
zombies = []
num_zombies = 5
game_start = False
lives = 5
speed = 2
awareness = 400
bspeed = 6
timer = 2
mines = []
key = Actor("coin")
key.y = 100
key.x = 100
player = Actor('fish')
player.x = 400
player.y = 300
bullets = []
shop = False
kills = 0
nob = False
white = (255, 255, 255)
music.play('suprise')
#background effects
stars = []
starmove = []
for i in range(200):
    star = rect((400, 300), (2, 2))
    star.angle = randint(0, 360)
    stars.append(star)
    move = randint(3, 7)
    starmove.append(move)

#function is called on every level progression
def new_level():
    global bullets
    global speedupgrade
    global level
    global num_zombies
    global zombies
    global zspeed
    global mines
    global speed
    global mines
    global nob
    nob= False
    num_zombies=2
    speed = 2 + speedupgrade
    for i in range(num_zombies):
        zombie = Actor("crab")
        zombie.x = randint(20, 780)
        zombie.y = randint(20, 580)
        zombies.append(zombie)
    for zombie in zombies:
        zombie.x = randint(20, 780)
        zombie.y = randint(20, 580)
        if zombie.distance_to(player) < 100:
            zombie.x = randint(20, 780)
            zombie.y = randint(20, 580)
    bullets = []
    level +=1
    mines = []

#initial game start
new_level()

#objective placer
def place_key():
    key.x = randint(20, 780)
    key.y = randint(20, 580)

#the crabs(zombies) move randomly, only chasing the player if they see it
def zombie_move(a):
    if game_start:
        global zspeed
        distance = math.sqrt((int(a.y)-int(player.y))*(int(a.y)-int(player.y))+(int(a.x)-int(player.x))*(int(a.x)-int(player.x)))
        if distance < awareness:
            if player.x > a.x:
                a.x += zspeed
            else:
                a.x -= zspeed
            if player.y < a.y:
                a.y -= zspeed
            else:
                a.y += zspeed
        else:
            x_move = randint(-1, 1)
            y_move = randint(-1, 1)
            a.x += x_move * zspeed
            a.y += y_move * zspeed

#keeps the player inside the window
def check_inside():
    if player.x >= 800:
        player.x = 1
    if player.x <= 0:
        player.x =799
    if player.y >= 600:
        player.y = 1
    if player.y <= 0:
        player.y =599

#function called to place a mine
def place_mine():
    global mines
    if len(mines) <= 5:
        mine = Actor('mine')
        mine.x = player.x
        mine.y = player.y
        mines.append(mine)

def reload():
    global bullets
    global nob
    bullets = []
    nob = False

#we used on key down to limit the speed you can place the mines
def on_key_down():
    global mines
    global nob
    global bullets
    if keyboard.lctrl:
        place_mine()
    if nob:
        if keyboard.r:
            clock.schedule(reload, 1.0)

#on mouse down is used to make the bullets and give them a starting (x, y) and angle
#nob = no bullets
def on_mouse_down():
    sounds.bulletsound.play()
    global nob
    if len(bullets)<30:
        mousepos = pygame.mouse.get_pos()
        bullet = Actor('bulletright')
        bullet.x = player.x
        bullet.y = player.y
        bullets.append(bullet)
        bullet.angle = bullet.angle_to(mousepos)
    else:
        nob = True
def update():
    global starmove
    global stars
    global nob
    global bspeed
    global mines
    global zspeed
    global zombies
    global speed
    global lives
    global awareness
    global bullets
    global funny
    global z
    global kills
    global r
    global g
    global b
    global playagain


    #sets the player rotation
    mousepos = pygame.mouse.get_pos()
    player.angle = (player.angle_to(mousepos))+180

#makes the game slowly get more difficult as time goes on
    if game_start:
        awareness += 0.0005
        zspeed += 0.00001

    check_inside()
    k = 0
    for star in stars:
        b = math.radians(star.angle)
        l = starmove[k]
        star.y -= math.sin(b)*l
        star.x += math.cos(b)*l
        if star.y >= 600:
            star.y = 300
            star.x = 400
            star.angle = randint(0, 360)
        if star.y <= 0:
            star.y = 300
            star.x = 400
            star.angle = randint(0, 360)
        if star.x >= 800:
            star.x = 400
            star.y = 300
            star.angle = randint(0, 360)
        if star.x <= 0:
            star.x = 400
            star.y = 300
            star.angle = randint(0, 360)
            k = k+1
    #we use sine and cosine values to move the bullet a total distance of one, then multiply that by out bullet speed
    for bullet in bullets:
        b = math.radians(bullet.angle)
        bullet.y -= math.sin(b)*bspeed
        bullet.x += math.cos(b)*bspeed
    
    #checks if the player has reached the objective
    if player.colliderect(key):
        new_level()
        place_key()   

    # the player can only move if its alive (duh)
    if lives >0 :
        if keyboard.a:
            player.x -= speed
        if keyboard.s:
            player.y += speed
        if keyboard.d:
            player.x += speed
        if keyboard.w:
            player.y -= speed
    
    #resets the zombie position if they damage the character, and removes them if a bullet/mine touches them
    #we added a kill counter here too
    for zombie in zombies:
        zombie_move(zombie)
        if player.colliderect(zombie):
            lives -= 1
            zombie.x = randint(20, 780)
            zombie.y = randint(20, 580)      
        for mine in mines:
            if mine.colliderect(zombie):
                zombie.x = 5000
                zombie.y = 5000
                mine.x = -5000
                mine.y = -5000
                kills += 1
        for bullet in bullets:
            if bullet.colliderect(zombie):
                zombie.x = 5000
                zombie.y = 5000
                bullet.x = -5000
                bullet.y = -5000
                kills += 1  
  
def draw():
    global bullets
    global mines
    global speed
    global lives
    global level
    global num_zombies
    global zombies
    global game_start
    global shop
    global funny
    global kills
    global zspeed
    global lifeupgrade
    global speedupgrade
    global stars

    #initial start screen setup 
    screen.fill('red')
    screen.draw.text(('COD(fish) ZOMBIES'), midtop= (400, 300), fontsize = 80)
    screen.draw.text(('PRESS SPACE TO PLAY'), topleft = (130, 400), fontsize = 60)
    screen.draw.text(('avoid red crabs and reach the objective'), topleft = (100, 500), fontsize = 40)
    screen.draw.text(('m1/m2:shoot\n lctrl: mines \nw,a,s,d:move'), midtop= (400, 100), fontsize = 40)


    #we used booleans to show different screens of the game
    if keyboard.space:
        game_start = True

    #here is the actual game setup
    if game_start:
        sigma = (85, 0, 85)
        screen.fill(sigma)
        

        for star in stars:
            screen.draw.rect(star, white)
        screen.draw.filled_circle((400, 300), 30, sigma)
        
        player.draw()
        key.draw()

        screen.draw.text(('LIVES: '+str(lives)), topleft = (300, 15), fontsize = 60)
        screen.draw.text(('LEVEL: '+str(level)), topleft = (300, 50), fontsize = 60)
        screen.draw.text(('KILLS: '+str(kills)), topleft = (0, 0), fontsize = 40)

        #tracks your bullets on the top right, and tells you when to reload
        if nob:
            screen.draw.text(('RELOAD(R)'), topright = (800, 0), fontsize = 40)
        else:
            a = len(bullets)
            screen.draw.text(('AMMO: '+str(30-a)+'/30'), topright = (800, 0), fontsize = 40)

        for zombie in zombies:
            zombie.draw()

        for mine in mines:
            mine.draw()

        for bullet in bullets:
            bullet.draw()

        #when the player dies they can get upgrades or restart normally
        if lives <= 0:
            screen.fill('blue')
            #calculates score and end results
            score = ((level*10)+(kills*2))
            screen.draw.text('GAME OVER, PRESS F TO RESTART', topleft = (60,100), fontsize = 60)
            screen.draw.text(('YOU DIED AT LEVEL: '+str(level)), topleft = (200, 50), fontsize = 60)
            screen.draw.text(('score: '+ str(score) ), midtop = (400, 10), fontsize = 60)
            screen.draw.text('PRESS G FOR UPGRADES', topleft = (120,150), fontsize = 60)
            if keyboard.f:
                lives = 5 + lifeupgrade
                level = 0
                zombies = []
                num_zombies = 2
                new_level()
                zspeed = 1
                kills = 0
                speed = 2 + speedupgrade
            
            if keyboard.g:
                shop = True

            if shop:
                screen.fill('red')
                screen.draw.text(('CHOOSE ONE: '), topleft = (100, 50), fontsize = 60)
                screen.draw.text('more lives(press q)', topleft = (60,100), fontsize = 60)
                screen.draw.text('more speed(press e)', topleft = (60,160), fontsize = 60)
                if keyboard.q:
                    lifeupgrade +=1
                    lives = 5 + lifeupgrade
                    speed = 2 + speedupgrade
                    level = 0
                    zombies = []
                    mines = []
                    zspeed = 1
                    num_zombies = 2
                    new_level()
                    shop = False
                    kills = 0

                if keyboard.e:
                    speedupgrade += 2
                    speed = 2 + speedupgrade
                    lives = 5 + lifeupgrade
                    level = 0
                    mines = []
                    zombies = []
                    num_zombies = 2
                    zspeed = 1
                    new_level()
                    shop = False
                    kills = 0
pgzrun.go()